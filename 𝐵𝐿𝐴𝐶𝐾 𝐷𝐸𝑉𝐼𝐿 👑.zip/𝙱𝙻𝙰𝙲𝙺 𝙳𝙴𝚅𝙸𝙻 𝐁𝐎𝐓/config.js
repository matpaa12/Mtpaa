require("./database/module")

//GLOBAL PAYMENT
global.storename = "𝑘𝑖𝑛𝑔-𝑎𝑙𝑑𝒉𝑎𝑙𝑒𝑎  "
global.dana = "967737617519"
global.qris = "gada qris gw anjg"


// GLOBAL SETTING
global.owner = "967737617519 "
global.namabot = "𝑘𝑖𝑛𝑔-𝑎𝑙𝑑𝒉𝑎𝑙𝑒𝑎  "
global.nomorbot = "967737617519"
global.namaCreator = "𝑘𝑖𝑛𝑔-𝑎𝑙𝑑𝒉𝑎𝑙𝑒𝑎 "
global.linkyt = ""
global.autoJoin = false
global.antilink = false
global.versisc = '1.0.0'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = ''
global.isLink = 'https://whatsapp.com/channel/0029Vap3QwxI1rcr8XcemK0b'
global.packname = "𝘒𝘐𝘕𝘎 𝘈𝘓𝘋𝘏𝘈𝘓𝘌𝘈꧂"
global.author = "☠︎︎︎~DEVIL☠︎"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})